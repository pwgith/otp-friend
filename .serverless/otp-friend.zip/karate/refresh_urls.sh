# For this to be called from serverless you have to install script plugins:
#    npm install --save serverless-plugin-scripts
#    serverless plugin install -n serverless-plugin-scripts
# And add the following to the serverless yml file:
# custom:
#   scripts:
#     hooks:
#       'deploy:finalize': karate/refresh_urls.sh

serverless info --verbose | grep -e POST -e GET -e PATCH > karate/all_urls.txt
grep "POST.*otp$" karate/all_urls.txt  | sed -n 's/^.* - //p' | tr -d '\n' > karate/url_otp_post.txt
grep "POST.*otp_okta$" karate/all_urls.txt  | sed -n 's/^.* - //p' | tr -d '\n' > karate/url_otp_okta_post.txt
grep "GET.*otp$" karate/all_urls.txt  | sed -n 's/^.* - //p' | tr -d '\n' > karate/url_otp_get.txt
