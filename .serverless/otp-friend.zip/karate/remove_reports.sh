rm -rf target/karate-reports*
rm target/karate.log