npm install -g serverless
npm install --save serverless-plugin-scripts
serverless plugin install -n serverless-plugin-scripts
pip install boto3
