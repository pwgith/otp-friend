npm install -g serverless
pip install boto3
