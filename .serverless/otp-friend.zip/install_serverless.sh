npm install -g serverless
npm install --save serverless-plugin-scripts
serverless plugin install -n serverless-plugin-scripts
pip install boto3
wget https://github.com/karatelabs/karate/releases/download/v1.4.1/karate-1.4.1.jar
# move the jar into the karate directory
